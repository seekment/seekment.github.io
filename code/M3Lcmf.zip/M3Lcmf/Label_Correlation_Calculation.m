function [Label_correlation,numCooccurrence_c1c2] = Label_Correlation_Calculation(label_target)
[num_labeled_bag,num_label]=size(label_target);%label_target 285*340
numCooccurrence_c1c2=zeros(num_label,num_label);% number of label c1 and label c2 when they co-occurred
Cor_c1c2=zeros(num_label,num_label);%the correlations between c1 and c2
Label_correlation=zeros(num_label,num_label);

%% 1.label correlation calculation
for i=1:num_labeled_bag
    for j=1:num_label
        if label_target(i,j)==-1
           label_target(i,j)=0;
        end
    end
end
label_target=label_target';

%1.calculate correlations between label c1 and label c2 (d:label*label)
for i=1:num_label
    for j=1:num_label
         if(j~=i)
            for k=1:num_labeled_bag
                if dot(label_target(i,:),label_target(j,:))==0
                    Label_correlation(i,j)=0;
                else 
                    Label_correlation(i,j)=dot(label_target(i,:),label_target(j,:))/(norm(label_target(i,:))*norm(label_target(j,:)));
                end
            end
        else
            Label_correlation(i,j)=1;
        end   
    end
end

end

