function []=main_M3Lcmf(dataset)
%% This is the main function of M3Lcmf
%% INPUTS: 
%   bags(n*1): The features of n bags 
%   target(c*n): The labels of n bags
%% Matrix demonstration
%   R12(n*m): sorts the relations of bags and instances
%   R23(n*m): sorts the relations of instance and labels
%   R13(n*m): sorts the relations of bags and labels
%   G1(n*dim): The low-rank representation of bags
%   G2(m*dim): The low-rank representation of instances
%   R3(c*dim): The low-rank representation of labels
%% OUTPUTS: 
%   Ouputs(n*c): Likelihoods of the test bags 
%   Pre_Labels(n*c): Labels prediction of the test bags
%   weight1: alpha_v in paper, which controls the weights of bag subsetwotk
%   weight2: beta_v in paper, which controls the weights of instance subsetwotk
%dataset='example_date.mat';
%load(dataset); 
num=10; %run times ���д���
dim=10; 
item=17; %number of iterations ��������
k=3;
q=4;
lemeda1=1*(10^k); 
lemeda2=1*(10^q); 

alpha=1; %constant variable
beta=1; %constant variable
gama=1; %constant variable

load(dataset);
[row,col]=size(bags);
train_bags=cell(row,col);
for i=1:row
    train_bags{i,1}=bags{i,1}';
end  
train_target=transpose(target);
for m=1:num  
    [row,col]=size(train_bags);
    [row,l]=size(train_target);
    for i=1:row
        for j=1:l
            if train_target(i,j)==-1
                train_target(i,j)=0;
            end
        end
    end
    num_train=round(row*0.7);%70%��ѵ������30%��Ԥ�⼯
    row1=num_train; %the number of labeled samples 70
    row2=row-num_train; %the number of test samples  30
    k1=row1;
    %% 1.Dispose data for M3Lcmf
    [train_label_bags,test_bags,train_label_target,test_target]=data_dispose_M3L(row1,row2,k1,col,l,train_bags,train_target);%�õ�ѵ�����ݺͱ�ǣ��������ݺͱ��
    t0 = cputime;
    [label_bags1,test_bags1,label_bags2,test_bags2] = View_partition(train_label_bags,test_bags);%�����ݼ�����Ϊ2����ͼ(����bag����instance�������������)
    %% 2.Calcuate the label correlation matrix R33
    %%?????[Label_correlation,numCooccurrence_c1c2] = Label_Correlation_Calculation(train_label_target);%�����ǩ��ؾ���
   
    %% 3.Calcuate the bag correlation matrix and instance correlation matrix of each view ��R11��R22,A(��ͬ��ͼlamda��P)��target=��train_label_target��test_target��
    %ok[Bag_correlation1,Instance_correlation1,P,target] = M3_correlation_new1(label_bags1,train_label_target,test_bags1,test_target);
    %ok[Bag_correlation2,Instance_correlation2,P,target] = M3_correlation_new1(label_bags2,train_label_target,test_bags2,test_target);
    
    %% 4.Initialization of M3Lcmf 
    [Initial_G1,Initial_G2,Initial_G3,Initial_R12,Initial_R13,Initial_R23,num_labeled_bag] = Initial(train_label_bags,train_label_target,test_bags,test_target,dim);%dimΪ10
    %% 5.M3L based on Collaborative Matrix Factorization(M3Lcmf)
    [Outputs,Pre_Labels,R12,R13,R23,G1,G2,G3,weight1,weight2] = M3Lcmf_w(Bag_correlation1,Bag_correlation2,Instance_correlation1,Instance_correlation2,Label_correlation,alpha,beta,gama,Initial_G1,Initial_G2,Initial_G3,Initial_R12,Initial_R13,Initial_R23,P,test_target,num_labeled_bag,train_label_target,item,dim,lemeda1,lemeda2);
    cost_time = cputime - t0;
    fprintf('\n ************ weight11=%d\n, weight12=%d\n, weight21=%d\n, weight22=%d\n',weight1(1),weight1(2),weight2(1),weight2(2));
end  
end

