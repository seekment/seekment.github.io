Title: Multi-View Multi-Instance Multi-Label Learning based on Collaborative Matrix Factorization(M3Lcmf)
Version: 1.0
Author: Yuying Xing <yyxing4148@email.swu.edu.cn>
Description: This package implements the M3Lcmf algorithm.
Depends:MATLAB (>= 2014b)

Files:

main_M3Lcmf.m: The main function for the algorithm.
Initial.m: Matrix initialization of M3Lcmf
M3Lcmf_w: M3L based on Collaborative Matrix Factorization


- This package includes the codes of M3Lcmf which are implemented and tested on Matlab2014b version by Yuying Xing (Email: yyxing4148@email.swu.edu.cn) and free for academic usage.
You can run it at your own disk. 
- If you have any problem on using these codes, please feel free to contact Xing. 
- For other purposes, please contact Dr. Yu (Guoxian Yu, Email: gxyu@swu.edu.cn). 