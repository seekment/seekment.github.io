function [Initial_G1,Initial_G2,Initial_G3,Initial_R12,Initial_R13,Initial_R23,num_labeled_bag] = Initial(label_bags,label_target,test_bags,test_target,dim)

[num_labeled_bag,num_labeled_instance]=size(label_bags);%285*1
[num_labeled_bag,num_label]=size(label_target);%285*340

[num_test_bag,num_test_instance]=size(test_bags);%122*1
[num_test_bag,num_label]=size(test_target);%122*340

Initial_labeled_R12=zeros(num_labeled_bag,num_labeled_instance);
Initial_labeled_R13=zeros(num_labeled_bag,num_label);
Initial_labeled_R23=zeros(num_labeled_instance,num_label);

Initial_test_R12=zeros(num_test_bag,num_test_instance);%
Initial_test_R13=zeros(num_test_bag,num_label);
Initial_test_R23=zeros(num_test_instance,num_label);

Norm = 2;
NormV = 0;

%% 1.Initial labeled R12
[num_labeled_bag,num_labeled_instance]=size(label_bags);
temp=0;
for i=1:num_labeled_bag
    Temp_i_instance=label_bags{i,1}';  %ת���Ժ����3�ж���
    [num_i_instance,Labeled_dimension]=size(Temp_i_instance);
    temp=temp+num_i_instance; 
    if i==1
        Initial_labeled_R12(i,1:num_i_instance)=1;%�Ѹ�bag�µĵ�instance���Ϊ1��
        Initial_labeled_R12(i,num_i_instance+1:end)=0;%����instanceΪ0
    end
    if 1<i<num_labeled_bag
        Initial_labeled_R12(i,1:temp-num_i_instance)=0;%temp������һ���ж��ٸ�instance
        Initial_labeled_R12(i,temp-num_i_instance+1:temp)=1;%�ڸ�bag�²Ż�������instance�й�ϵ
        Initial_labeled_R12(i,temp+1:end)=0;
    end
    if i==num_labeled_bag
        Initial_labeled_R12(i,1:temp-num_i_instance)=0;
        Initial_labeled_R12(i,temp-num_i_instance+1:temp)=1;
    end
end

%% 2.Initial labeled R13
[num_labeled_bag,num_label]=size(label_target);%285*340
for i=1:num_labeled_bag
    for j=1:num_label
       if label_target(i,j)==-1
           label_target(i,j)=0;
       end
    end
end
Initial_labeled_R13=label_target;

%% 3.Initial labeled R23
[num_labeled_bag,num_label]=size(label_target);%285*340
temp=0;
for i=1:num_labeled_bag
    Temp_i_instance=label_bags{i,1}';  
    [num_i_instance,Labeled_dimension]=size(Temp_i_instance);
    temp=temp+num_i_instance;   
    for j=1:num_labeled_instance
        for k=1:num_label
            Initial_labeled_R23(temp-num_i_instance+1:temp,k)=label_target(i,k);%��bag �ı�ǩ��ʼΪinstanse �ı�ǩ
        end
    end
end

%% 4.Consider test data(test_bags and initial test_target)
%4.1 initial R12
[num_test_bag,num_test_instance]=size(test_bags);
temp1=0;
for i=1:num_test_bag
    Temp_i_instance_test=test_bags{i,1}';  
    [num_i_instance_test,Labeled_dimension]=size(Temp_i_instance_test);
    temp1=temp1+num_i_instance_test;   
    if i==1
        Initial_test_R12(i,1:num_i_instance_test)=1;
        Initial_test_R12(i,num_i_instance_test+1:end)=0;
    end
    if 1<i<num_test_bag
        Initial_test_R12(i,1:temp1-num_i_instance_test)=0;
        Initial_test_R12(i,temp1-num_i_instance_test+1:temp1)=1;
        Initial_test_R12(i,temp1+1:end)=0;
    end
    if i==num_test_bag
        Initial_test_R12(i,1:temp1-num_i_instance_test)=0;
        Initial_test_R12(i,temp1-num_i_instance_test+1:temp1)=1;
    end
end

[num_labeled_bag,num_labeled_instance]=size(Initial_labeled_R12);%%%�����߼��ǣ���
[num_test_bag,num_test_instance]=size(Initial_test_R12);
Temp_lm_tn=zeros(num_labeled_bag,num_test_instance);%70*30
Temp_lm_lmtn=[Initial_labeled_R12,Temp_lm_tn];%������ѵ�����ݺ�test���� %70

Temp_tm_ln=zeros(num_test_bag,num_labeled_instance);
Temp_tm_lmtn=[Temp_tm_ln,Initial_test_R12]; %30

Initial_R12=[Temp_lm_lmtn;Temp_tm_lmtn];

%4.2 initial R13 
Initial_R13=[Initial_labeled_R13;Initial_test_R13];

%4.3 initial R23
[num_test_bag,num_label]=size(test_target);%122*340
temp2=0;
for i=1:num_test_bag
    Temp_i_instance_test=test_bags{i,1}';  
    [num_i_instancee_test,Labeled_dimension]=size(Temp_i_instance_test);
    temp2=temp2+num_i_instancee_test;   
    for j=1:num_test_instance
         for k=1:num_label
            Initial_test_R23(temp2-num_i_instancee_test+1:temp2,k)=0;
         end
    end
end
Initial_R23=[Initial_labeled_R23;Initial_test_R23];

%% 5.Initialize the G with SVD

%5.1 Initialize G1,G2 with bags
num_bag=num_labeled_bag+num_test_bag;
num_instance=num_labeled_instance+num_test_instance;

Initial_G1=zeros(num_bag,Labeled_dimension);
Initial_G2=zeros(num_instance,Labeled_dimension);

bags=[label_bags;test_bags];
[num_bag,num_instance]=size(bags);

for i=1:num_bag
    temp2=0;
    Temp_i_instance=bags{i,1}';
    [num_i_instance,Labeled_dimension]=size(Temp_i_instance);
    temp2=temp2+num_i_instance;
    Initial_G1(i,:)=(1/num_i_instance)*sum(Temp_i_instance);%�������
end
Initial_G2=cell2mat(bags');
Initial_G2=Initial_G2';

d_k1=dim;  %low-rank dim
d_k2=dim;  %low-rank dim
d_k3=dim;  %low-rank dim
[Initial_G1,z1]=learnVector2(Initial_R12,d_k1);
[Initial_G2,z2]=learnVector2(Initial_G2,d_k2);
[Initial_G3,z3]=learnVector2(Initial_R13(1:num_labeled_bag,:)',d_k3);
end

