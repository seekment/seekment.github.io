function [Outputs,Pre_Labels,R12,R13,R23,G1,G2,G3,weight1,weight2] = M3Lcmf_w(Bag_correlation1,Bag_correlation2,Instance_correlation1,Instance_correlation2,Label_correlation,alpha,beta,gama,Initial_G1,Initial_G2,Initial_G3,Initial_R12,Initial_R13,Initial_R23,P,test_target,num_labeled_bag,label_target,item,dim,lemeda1,lemeda2)
d_k=dim;%180
max_iter=item;%��������17
%Outputs ԭʼtest����
%Pre_Labels ��Outputs���������Ժ��ȹ�һ����Ȼ��>0.5Ϊ1���ӹ��������

[num_bag,d_k]=size(Initial_G1);
[num_instance,d_k]=size(Initial_G2);
[num_label,d_k]=size(Initial_G3);

[num_bag,num_instance]=size(Initial_R12);
[num_bag,num_label]=size(Initial_R13);
[num_instance,num_label]=size(Initial_R23);

[num_bag,num_bag]=size(P);%P num_bag*num_bag

R12=zeros(num_bag,num_instance);
R13=zeros(num_bag,num_label);
R23=zeros(num_instance,num_label);
 
threshold = 0.01;
R13=Initial_R13;
R12=Initial_R12;
R23=Initial_R23;

G1=Initial_G1;%
G2=Initial_G2;
G3=Initial_G3;

Norm = 2;
NormV = 0;

Theta11=zeros(num_bag,num_bag);
W11=Bag_correlation1;
D11=zeros(num_bag,num_bag);

Theta12=zeros(num_bag,num_bag);
W12=Bag_correlation2;
D12=zeros(num_bag,num_bag);

Theta21=zeros(num_instance,num_instance);
W21=Instance_correlation1;
D21=zeros(num_instance,num_instance);

Theta22=zeros(num_instance,num_instance);
W22=Instance_correlation2;
D22=zeros(num_instance,num_instance);

Theta3=zeros(num_label,num_label);
W3=Label_correlation;
D3=zeros(num_label,num_label);
%weight1
L=zeros(num_bag,num_bag);%
W=zeros(num_bag,num_bag);%
weight1=zeros(2,1);%
weight1=weight1+1/2;%
D1=cell(1,2);
L1=cell(1,2);
tr1=zeros(1,2);

%weight2
Li=zeros(num_instance,num_instance);%
Wi=zeros(num_instance,num_instance);%
weight2=zeros(2,1);%
weight2=weight2+1/2;%
D2=cell(1,2);
L2=cell(1,2);
tr2=zeros(1,2);
%==================================================================================
if alpha > 0
    W11 = alpha*W11;
    D11=diag(sum(W11,2));
    Theta11= D11 - W11;
    
    W12 = alpha*W12;
    D12=diag(sum(W12,2));
    Theta12= D12 - W12;

        for i=1:2
            L1{1,1}=Theta11;%������˹�任����v1
            L1{1,2}=Theta12;%������˹�任����v2
            W1{1,1}=W11;%instance1
            W1{1,2}=W12;%instance2
            D1{1,1}=D11;
            D1{1,2}=D12;
        end
        for i=1:2
            L=weight1(i,1)*L1{1,i}+L;%??????????????
            W=weight1(i,1)*W1{1,i}+W;
        end
else
    L =[];
end    
    D=diag(sum(W,2));%
%==================================================================================
if beta > 0

    W21 = beta*W21;
    D21=diag(sum(W21,2)); %R22
    Theta21= D21 - W21;

    W22 = beta*W22;
    D22=diag(sum(W22,2));
    Theta22= D22 - W22;
    
    for i=1:2
        L2{1,1}=Theta21;
        L2{1,2}=Theta22;
        W2{1,1}=W21;
        W2{1,2}=W22;
        D2{1,1}=D21;
        D2{1,2}=D22;
    end
    for i=1:2
        Li=weight2(i,1)*L2{1,i}+Li;
        Wi=weight2(i,1)*W2{1,i}+Wi;
    end
else
    Li=[];
end
    Di=diag(sum(Wi,2));%
%==================================================================================
if gama > 0
    W3 = gama*W3;
    D3=diag(sum(W3,2));
    Theta3= D3 - W3;
else
    Theta3 = [];
end
%==================================================================================
%% 1.Optimization G
for p=1:max_iter 
       % ===================== update G1 ========================
        G1_up = R12*G2+R13*G3; 
        G1_down=G1*G2'*G2+G1*G3'*G3;   
        
        if alpha >0 
            WG1 = W*G1;
            DG1 = D*G1;

            G1_up= G1_up+WG1;
            G1_down =G1_down+ DG1;
        end
       %
        G1 = G1.*(G1_up./max(G1_down,1e-10));  
        % ===================== update G2 ========================

        G2_up = R12'*G1+R12'*P'*R13*G3; 
        G2_down = G2*G1'*G1+R12'*P'*P*R12*G2*G3'*G3;  
        
        if beta >0 
            WG2 = Wi*G2;
            DG2 = Di*G2;
            
            G2_up= G2_up+WG2;
            G2_down =G2_down+ DG2;
        end
        G2 = G2.*(G2_up./max(G2_down,1e-10));  
        % ===================== update G3 ========================

        G3_up = R13'*G1+R13'*P*R12*G2; 
        G3_down =G3*G1'*G1+G3*G2'*R12'*P'*P*R12*G2;  
        
        if gama >0 
            WG3 = W3*G3;
            DG3 = D3*G3;
            
            G3_up= G3_up+WG3;%0
            G3_down =G3_down+ DG3;%
        end
        G3 = G3.*(G3_up./max(G3_down,1e-10));   
          % ===================== update weight1========================
        if alpha>0
                  
            for t=1:2
                VLV=G1'*L1{1,t}*G1;
                tr1(1,t)=trace(VLV);
            end
            [~,weight1]=getOptimalWeights(tr1,lemeda1);

            for i=1:2
                W=weight1(i,1)*W1{1,i}+W;
            end
            D=diag(sum(W,2));
        end
              % ===================== update weight2========================
        if beta>0      
            for t=1:2
                VLVi=G2'*L2{1,t}*G2;
                tr2(1,t)=trace(VLVi);
            end
            [~,weight2]=getOptimalWeights(tr2,lemeda2);

            for i=1:2
                Wi=weight2(i,1)*W2{1,i}+Wi;
            end
            Di=diag(sum(Wi,2));
        end

    %The judgment conditions 
    result = R23-G2*transpose(G3);
    R = sum(sum(result.^2));
    if R<threshold
        break;
    end
end
[G1] = Logistic_Regression(G1);
[G2, G3] = NormalizeG(G2, G3, NormV, Norm);
%% 2.Construct R23
R23=G2*transpose(G3);

%% 3.Predict for test_bags
[num_test_bag,num_label]=size(test_target);
Outputs=zeros(num_test_bag,num_label);
Pre_Labels=zeros(num_test_bag,num_label);

Outputs_all=P*R12*R23;  %bag���Ԥ��
[num_bag,num_label]=size(Outputs_all);
Outputs=Outputs_all(num_labeled_bag+1:end,:);

%the samllest value of Outputs
t = Outputs;
t(~t)=inf;%��T��Ϊ0��Ԫ�ر�Ϊinf ��A=[1 0 4;4 5 0]��t=A; t(~t)=inf t=[1 inf 4;4 5 inf]
[m,n]=find(t==min(min(t))); %����������Сֵ������
MinValue=t(m,n);  

%the largest value of Outputs  Ԥ���������ֵ������
[x,y]=find(Outputs==max(max(Outputs)));
MaxValue=Outputs(x,y);
for i=1:num_test_bag  %�Բ��Խ�����й�һ��
    for j=1:num_label
        Outputs(i,j)=(Outputs(i,j)-MinValue)*(1/(MaxValue-MinValue));
        if Outputs(i,j)<0
            Outputs(i,j)=0;
        end
    end
end

for i=1:num_test_bag
    for j=1:num_label
        if Outputs(i,j)>=0.5                  
            Pre_Labels(i,j)=1;
        else
            Pre_Labels(i,j)=0;
        end
    end
end
end                                          


