function [newX,Z,dim] = learnVector2(LabelMat,dim)
Q=LabelMat;
[row_Q,col_Q]=size(Q);
Zero_check_Q=zeros(row_Q,1);
Zero_check_Q=sum(Q,2);
[U,S,V]=svds(Q,dim);
SS=zeros(dim,dim);
X=sum(S(:));
X=fix(0.8*X);
temp=0;
for jj=1:Q
    temp=S(jj,jj)+temp;
    SS(jj,jj)=S(jj,jj);
    if temp>X
        break;
    end
end

line_S = diag(S);
sum_S = sum(line_S);
 
U = U(:,1:dim);
S = diag(line_S(1:dim));
V = V(:,1:dim);

percentage = sum(sum(S))/sum_S;
fprintf('this dim:%d  own percent: %-10.4f\n',dim,percentage);
X = U*sqrt(S);
Z = V*sqrt(S);

X = mapminmax(X,0,1);%��һ��ÿ��
minx = min(X,[],2);%�õ�ÿ����С
maxx=max(X,[],2);%�õ�ÿ�����
newX = X-repmat(minx,1,dim);

Z = mapminmax(Z,0,1);
