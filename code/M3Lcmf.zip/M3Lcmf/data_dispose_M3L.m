function  [train_label_bags,test_bags,train_label_target,test_target]=data_dispose_M3L(row1,row2,k1,col,l,train_bags,train_target)
    %row1 70
    % row2 30
     %k1 70 
    label_bags=zeros(row1,col);
    test_bags=zeros(row2,col);
    
    label_target=zeros(row1,l);
    test_target=zeros(row2,l);

    train_data_Rest=train_bags;
    train_target_Rest=train_target;
    
    [row,col]=size(train_data_Rest);%the size of train_data
    [row,l]=size(train_target_Rest);
    
    idx=randperm(row);
    l_idx=idx(1:k1);%�ȴ���˳��ȡ1��k1
    t_idx=idx(k1+1:end);
    
    train_label_bags=train_data_Rest(l_idx,:);  % 70
    train_label_target=train_target_Rest(l_idx,:);% 70
    
    test_bags=train_data_Rest(t_idx,:); % 30
    test_target=train_target_Rest(t_idx,:); % 30

