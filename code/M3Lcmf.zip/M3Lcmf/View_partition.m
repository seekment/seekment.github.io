function [label_bags1,test_bags1,label_bags2,test_bags2] = View_partition(label_bags,test_bags)
[num_labeled_bag,col]=size(label_bags);%label_bags 285*1
[num_test_bag,col]=size(test_bags);%test_bags 122*1

label_bags1=cell(num_labeled_bag,col);
label_bags2=cell(num_test_bag,col);

test_bags1=cell(num_test_bag,col);
test_bags2=cell(num_test_bag,col);
    
[temp_num_1_instance,dimension]=size(label_bags{1,1}');%�õ�ʾ������������3��216
k1=round(0.5*dimension);%108

idx=randperm(dimension);
l1_idx=idx(1:k1);%һ��Ϊl1_idx
l2_idx=idx(k1+1:end);%һ��Ϊl2_idx
    
for i=1:num_labeled_bag
    Temp_i_instance=label_bags{i,1}';  
    [num_i_instance,dimension]=size(Temp_i_instance);
    temp_label_bags1=zeros(num_i_instance,k1);
    temp_label_bags2=zeros(num_i_instance,k1);
    temp_label_bags1=Temp_i_instance(:,l1_idx);
    temp_label_bags2=Temp_i_instance(:,l2_idx);
    label_bags1{i,1}=temp_label_bags1;
    label_bags2{i,1}=temp_label_bags2;%���bag����bag1��bag2��ͼ
end

for j=1:num_test_bag
    Temp_j_instance=test_bags{j,1}';  
    [num_j_instance,dimension]=size(Temp_j_instance);
    temp_test_bags1=zeros(num_j_instance,k1);
    temp_test_bag2=zeros(num_j_instance,k1);
    temp_test_bags1=Temp_j_instance(:,l1_idx);
    temp_test_bags2=Temp_j_instance(:,l2_idx);
    test_bags1{j,1}=temp_test_bags1;
    test_bags2{j,1}=temp_test_bags2;
end    

end

