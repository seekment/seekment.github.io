function [Bag_correlation,Instance_correlation,P,target] = M3_correlation_new1(label_bags,label_target,test_bags,test_target)
[num_labeled_bag,num_label]=size(label_target);
[num_test_bag,num_label]=size(test_target);

num_bag=num_labeled_bag+num_test_bag;
P=zeros(num_bag,num_bag);%407*407

bags=[label_bags;test_bags];
target=[label_target;test_target];

%% 1.Bag correlation calculation R11
[num_bag,col]=size(bags);%285+122=407*1
Bag_correlation=zeros(num_bag,num_bag);%407*407
H_p_avg=zeros(num_bag,num_bag);
H_p_min=zeros(num_bag,num_bag);
H_p_max=zeros(num_bag,num_bag);
H_p=zeros(num_bag,num_bag);%407*407

for i=1:num_bag
    Temp_i_instance=bags{i,1}';  
    Temp_i_instance=Temp_i_instance';
    [num_i_instance,dimension]=size(Temp_i_instance);
    
    for j=1:num_bag
        Temp_j_instance=bags{j,1}';
        Temp_j_instance=Temp_j_instance';
        [num_j_instance,dimension]=size(Temp_j_instance);
        temp_distance=0;
        distance=zeros(num_i_instance,num_j_instance);
        if(j~=i)
            for p=1:num_i_instance
                for q=1:num_j_instance
                     for k=1:dimension
                        temp_distance =sqrt(sum((Temp_i_instance(p,k)-Temp_j_instance(q,k)).^2));
                     end
                     distance(p,q)=temp_distance;     %����õ���i��bag�ĵ�p��instance���j��bag�ĵ�q��instance        
                end           
            end
            H_p_avg(i,j)=(sum(min(distance,[],2))+sum(min(distance,[],1)))/(num_i_instance+num_j_instance);%min(distance,[],2����С��min(distance,[],1)����С
            H_p_min(i,j)=min(distance(:));
            H_p_max(i,j)=max(max(min(distance,[],2)),max(min(distance,[],1)));
            kernel2=sum(sum(distance))/(num_i_instance*num_j_instance);
   
            H_p(i,j)=1/3*(H_p_avg(i,j)+H_p_min(i,j)+H_p_max(i,j));%��Ϻ�˹������
            if H_p(i,j)~=0
                Bag_correlation(i,j)=exp(-H_p(i,j)/ (kernel2^2)); %R11
            else
                Bag_correlation(i,j)=0;
            end
            
            P(i,j)=0;
        else 
            Bag_correlation(i,j)=1;
            P(i,j)=1/num_i_instance;
        end
    end
end

%% 2.Instance correlation calculation R22
%2.1 Convert the bag cell array into a matrix
[num_bag,col]=size(bags);;%285+122=407*1
bags=cell2mat(bags);   %��bag�������ϲ�Ϊһ�������

%2.2 Calculate the correlation of instances 
[num_Instance,dimension]=size(bags);%1251��ʾ����216ά��
Instance_correlation=zeros(num_Instance,num_Instance);
distance_instance=zeros(num_Instance,num_Instance);
for i=1:num_Instance
    for j=1:num_Instance
        temp=0;
        for k=1:dimension              
           temp=sum((bags(i,k)-bags(j,k)).^2);  %����Ϊʲô�����ۼӣ���������������������������������������������������������������
        end
        distance_instance(i,j)=sqrt(temp);

     end
end 
kernel1=sum(sum(distance_instance))/(num_Instance*num_Instance);
for i=1:num_Instance
    for j=1:num_Instance
        if(j~=i)
            Instance_correlation(i,j)=exp(-distance_instance(i,j)/(kernel1^2)); 
        else
            Instance_correlation(i,j)=1;
        end
     end
end 
end

