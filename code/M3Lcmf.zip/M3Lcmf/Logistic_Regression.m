function [matrixA] = Logistic_Regression(matrixA)
%% Logically return the values in the matrix to 0-1
%input: matrixA
%output: matrixA after logistic regression(range:0-1)

[row,col]=size(matrixA);

%1.logistic regression for matrixA
for i=1:row
    for j=1:col
        matrixA(i,j)=matrixA(i,j)/sum(matrixA(i,:));
    end
end


end
% A=[1,2,3;4,5,6];
% [row,col]=size(A);
% 
% %1.logistic regression for matrixA
% for i=1:row
%     for j=1:col
%         A(i,j)=A(i,j)/sum(A(i,:));
%     end
% end



