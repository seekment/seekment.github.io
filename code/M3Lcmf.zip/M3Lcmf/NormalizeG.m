function [G2, G3] = NormalizeG(G2, G3, NormV, Norm)
    K = size(G2,2);%G2�ж�����
    if Norm == 2
        if NormV
            norms = max(1e-15,sqrt(sum(G3.^2,1)))';
            G3 = G3*spdiags(norms.^-1,0,K,K);
            G2 =G2*spdiags(norms,0,K,K);
        else
            norms = max(1e-15,sqrt(sum(G2.^2,1)))';
            G2 = G2*spdiags(norms.^-1,0,K,K);
            G3 = G3*spdiags(norms,0,K,K);
        end
    else
        if NormV
            norms = max(1e-15,sum(abs(G3),1))';
            G3 = G3*spdiags(norms.^-1,0,K,K);
            G2 = G2*spdiags(norms,0,K,K);
        else
            norms = max(1e-15,sum(abs(G2),1))';
            G2 = G2*spdiags(norms.^-1,0,K,K);
            G3 = G3*spdiags(norms,0,K,K);
        end
    end
end
