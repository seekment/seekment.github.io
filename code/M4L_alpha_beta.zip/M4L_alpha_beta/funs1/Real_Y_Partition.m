function [newZ]=Real_Y_Partition(Z,Y)
%partite the elements as relevant and the left as irrelavant, the relevant
%number of elements is determined by the numer of labels in Y
%input  Z(Ndata x Nfun): predicted probability 
%       Y: the ground truth labels
%output newZ(Ndata x Nfun): partitioned relevant and irrelevant labels (1) for relevant and (-1) for irrelevant
%   written by Guoxian Yu (guoxian85@gmail.com), School of Computer Science and Engineering,
%   South China University of Technology.
%   version 1.0 date:2012-03-21
[Ndata,Nfun]=size(Z);
newZ=-ones(Ndata,Nfun);
for ii=1:Ndata
    [sorted, index] = sort(Z(ii,:),'descend');
    count=length(find(Y(ii,:)>0));
    newZ(ii,index(1:count))=1;
end