function [fmax, pr2, rc2]=FMax(scores, labels)
%Computing the Fmax score metrix
% for the definition of Fmax (see Predrag Radivojac, et. al., Vol. 10 (3), 2013, Nature Methods)
%   coded by Guoxian Yu (guoxian85@gmail.com), College of Computer and Information Science,
%   Southwest University.
%   version 1.0 date:2014-05-27

labels=transform_one_zero(labels);%transform [-1,1] to [0, 1]
step=0.001;
maxTH=max(max(scores))+step;
minTH=min(min(scores))-step;
% maxTH=min(1, maxTH);
step=(maxTH-minTH)/1000;
thresholds=minTH:step:maxTH;%the thresholds
[Ndata, Nfun] = size(labels);
pr=zeros(Ndata, length(thresholds));
rc=zeros(Ndata, length(thresholds));
m=zeros(Ndata, length(thresholds));

pr2=zeros(length(thresholds),1);
rc2=zeros(length(thresholds),1);

for ii=1:Ndata
    t_idx=find(labels(ii,:) >0);
    for jj=1:length(thresholds)
        th=thresholds(jj);
        f_idx=find(scores(ii,:)>=th);
        tp=intersect(f_idx, t_idx);
        if  ~isempty (f_idx) && ~ isempty(tp)%precision
            pr(ii,jj)=length(tp)/length(f_idx);%precision
        end
        if ~isempty(t_idx) && ~isempty(tp)
            rc(ii,jj)=length(tp)/length(t_idx);%recall
        end
        m(ii,jj)=length(f_idx);
    end
%     fprintf('processed %d, %s\n', ii, datestr(now));
end


for jj=1:length(thresholds)
     p_idx=find(m(:,jj)>=1);
     if ~isempty(p_idx)
        pr2(jj)=sum(pr(p_idx,jj))/length(p_idx);
     end
     rc2(jj)=sum(rc(:,jj))/Ndata;
%       fprintf('threshold %f, %s\n', thresholds(jj), datestr(now));
end

Fs=2*(pr2.* rc2)./(pr2+rc2);
Fs(isnan(Fs))=0;
Fs(isinf(Fs))=0;
[fmax, t_idx]=max(Fs);
