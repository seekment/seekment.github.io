function [Z]=TransLabelSetPrediction(Z,Y,W,lab_num)
[Ndata,Nfun]=size(Y);
A=eye(Ndata,Ndata)-W;
U1=sum(Y,2);
Auu=A(lab_num+1:Ndata,lab_num+1:Ndata);
Aul=A(lab_num+1:Ndata,1:lab_num);
U2=-Auu\Aul*U1(1:lab_num,:);

Z(1:lab_num,:)=2*Y(1:lab_num,1:Nfun)-ones(lab_num,Nfun);
TempZ=-ones(Ndata-lab_num,Nfun);
for ii=1:size(U2,1)
   [sorted,index]=sort(Z(lab_num+ii,:),'descend');
   label_size=round(U2(ii));
   if label_size>Nfun
        label_size=Nfun;
   else if label_size<=0
           label_size=1;
       end
   end
   TempZ(ii,index(1:label_size))=1;
end
Z(lab_num+1:Ndata,:)=TempZ;
