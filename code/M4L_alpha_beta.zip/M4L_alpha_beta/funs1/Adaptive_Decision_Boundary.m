function [B]=Adaptive_Decision_Boundary(Y,Z)
% Adaptive_Decision_Boundary(Y,Z), Get the adaptive decision boundary based on minimizing Bayes Error
% Input Y: the multi-label matrix (NxC), C is the number of labels, in 1 and -1 form, 1 means labeled and 0 donates unlabeled.
%       Z: the predicted labels (NxC)
% Output: B, 1 x C adaptive boundary
%   written by Guoxian Yu (guoxian85@gmail.com), School of Computer Science and Engineering,
%   South China University of Technology.
%   version 1.0 date:2011-12-11
[N,C]=size(Y);
if(min(min(Y))==0)
    Y=2*Y-ones(size(Y));%change to 1 and -1 
end
B=zeros(C,1);
step_size=0.001;

for cc=1:C
    bayes_error=realmax;
    p_idx=find(Y(:,cc)>0);
    n_idx=find(Y(:,cc)<0);
    np=length(p_idx);
    nn=length(n_idx);
    if(np==0)
        np=1;
    end
    if(nn==0)
        nn=1;
    end
    [sorted,index]=sort(Z(:,cc),'ascend');
%     minval=min(Z(:,cc));
%     maxval=max(Z(:,cc));
    thresholds=zeros(N+2,1);
    thresholds(1)=0;
    thresholds(2:N+1)=sorted;
    thresholds(N+2)=1;
    for ii=1:length(thresholds);
        threshold=thresholds(ii);
        Zcc=Z(:,cc);
        p_idx1=find(Z(:,cc)>=threshold);
        n_idx1=find(Z(:,cc)<threshold);
        Zcc(p_idx1)=1;
        Zcc(n_idx1)=-1;
        ConfMat = ConfusionMatrix(Y(:,cc), Zcc);
        Err=ConfMat(1,2)/np+ConfMat(2,1)/nn;
        if(Err<bayes_error)
            bayes_error=Err;
            B(cc)=threshold;
        end
    end
end