function [masked_Y]=Mask_Label(Y,mask_ratio)
% mask some labels of the multi-label data with mask_ratio
% Input Y: the multi-label matrix (NxC), C is the number of labels, in 1 and 0 form, 1 means labeled and 0 donates unlabeled.
%   mask_ratio: [0,1] the percentage of incomplete labels onmulti-label data
% Output: masked_Y: masked label vector with
%   written by Guoxian Yu (guoxian85@gmail.com), School of Computer Science and Engineering,
%   South China University of Technology.
%   version 1.0 date:2011-12-11
[Ndata,Nfun]=size(Y);
masked_Y=Y;
Nlabels=sum(sum(Y));
masked_Count=fix(Nlabels*mask_ratio);
count=0;
while count<masked_Count
    idx=randperm(Ndata);
    jj=1;
    while (jj<=Ndata) && (count<masked_Count)
        ii=idx(jj);
        Yii=masked_Y(ii,:);
        if sum(Yii)>0 && count<masked_Count
            idx2=find(Yii>0);
            idx3=randperm(length(idx2));
            
            cc=1;
            idx4=idx2(idx3(cc));
            stat=sum(Y(:,idx4));
            while (stat==1) && (cc < length(idx2)) %Y only have one samples labeled with idx4;
                cc=cc+1;
                idx4=idx2(idx3(cc));
                stat=sum(Y(:,idx4));
            end
            stat=sum(masked_Y(:,idx4));
            if stat>1
                Yii(idx4)=0;%masked
                masked_Y(ii,:)=Yii;
                count=count+1;
            end
        end
        jj=jj+1;
    end
end
aa=0;