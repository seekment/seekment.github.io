function rbpath= rbconstruct(first,second,weight,rbpath)
%author:blueart date:2011-12-25
%find the connected nodes in two different clusters (unconnected nodes are all zeros)
y1=find(rbpath(first,:));%first node connected nodes
y2=find(rbpath(second,:));%second node connected nodes
x=union(y1,y2);
xs=size(x,1);
for i=1:xs
    xindex=x(i);
    for j=(i+1):xs
        yindex=x(j);
        if(rbpath(xindex,yindex)==0)%xindex,yindex are not connected in two clusters
            rbpath(xindex,yindex)=weight;
            rbpath(yindex,xindex)=weight;
        end
    end
    rbpath(xindex,xindex)=0;
end


