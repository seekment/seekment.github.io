function [ EnsZ ] = WeightEnsemble(Zs)
%function [ EnsZ ] = WeightEnsemble(Zs)
%combine basic classifiers with weights
[Nclassifier,Ndata,Nfun]=size(Zs);
EnsZ=zeros(Ndata,Nfun);
tol=0.0000001;
Weights=zeros(Nclassifier,Ndata);


for c_idx=1:Nclassifier
    for d_idx = 1:Ndata
        weight=0;
        for f_idx = 1:Nfun
            p=Zs(c_idx,d_idx,f_idx);
            weight = weight + p*(1-p);
        end
        Weights(c_idx,d_idx)= 1-weight;%big weight equals random guess
    end
end

D=diag(sum(Weights,1))+tol*eye(size(Weights,2));
Weights= Weights/D;


for c_idx=1:Nclassifier
    for d_idx=1:Ndata
        Z=reshape(Zs(c_idx,d_idx,:),1,Nfun);
        EnsZ(d_idx,:)=EnsZ(d_idx,:)+Z*Weights(c_idx,d_idx);
    end
end


% A=[1/2,1/3,1/6];
% B=[1/2,1/2,0];
%
% A(A==0)=0.0000001;
% A(A==1)=0.9999999;
%
% a=0;
% for ii=1:3
%     a=a+A(ii)*(1-A(ii));
% end
% 1-a
%
% a=0;
% for ii=1:3
%     a=a+B(ii)*(1-B(ii));
% end
% 1-a
