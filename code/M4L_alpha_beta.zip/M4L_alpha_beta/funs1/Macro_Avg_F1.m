function MacroAvgF1=Macro_Avg_F1(Outputs,test_target)
%Computing the Micro Average F1
%Outputs: the predicted outputs of the classifier, the output of the ith instance for the jth class is stored in Outputs(j,i)
%test_target: the actual labels of the test instances, if the ith instance belong to the jth class, test_target(j,i)=1, otherwise test_target(j,i)=-1)
%   written by Guoxian Yu (guoxian85@gmail.com), School of Computer Science and Engineering,
%   South China University of Technology.
%   version 1.0 date:2011-11-15
Outputs=transform_one_zero(Outputs);
test_target=transform_one_zero(test_target);
C=size(test_target,1);
div=0;
for c=1:C
    pr=Outputs(c,:)*(test_target(c,:)');
    np=sum(Outputs(c,:));
    if np==0
        np=1;
    end
    precision=pr/np;
    
    np=sum(test_target(c,:));
    if np==0
        np=1;
    end
    recall=pr/np;
    pr=precision+recall;
    if pr==0
        pr=1;
    end
    div=div+(2*precision*recall)/pr;
end
MacroAvgF1=div/C;