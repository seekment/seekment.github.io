function [MicroF1,MacroF1,AvgROC,HammLoss,RankLoss,OneError,AvgPrec,Cov]=PerformanceEvaluation(dataset,metod,run,trueY,preY,topK)
newY=trueY;
rocZ=preY;
 Z=Top_K_Partition(preY,TopK);
RocScore=zeros(1,size(newY,2));
for cls=1:size(newY,2)
    RocScore(cls) = calcrocscore(rocZ(:,cls)',newY(:,cls)');
end%end for cls=1:C
MicroF1s(mask_idx,run,:)=F1Scores(Z',newY');
RocScores(mask_idx,run,:)=RocScore;

MicroAvgF1s(mask_idx,run)=Micro_Avg_F1(Z',newY');
MacroAvgF1s(mask_idx,run)=Macro_Avg_F1(Z',newY');
RocAvgScores(mask_idx,run) = sum(RocScore)/size(newY,2);
fprintf('==Dataset:%s, Method=%s  Run=%d, time:%s\n',run,datestr(now));
fprintf('MicroAvgF1=%-10.4f,MacroAvgF1=%-10.4f,RocAvgScore=%-10.4f\n',...
    MicroAvgF1s(mask_idx,run),MacroAvgF1s(mask_idx,run),RocAvgScores(mask_idx,run));

HammingLosses(mask_idx,run) = 1-Hamming_loss(Z',newY');
RankingLosses(mask_idx,run) = 1-Ranking_loss(rocZ',newY');
OneErrors(mask_idx,run) = 1-One_error(rocZ',newY');
AveragePrecisions(mask_idx,run) = Average_precision(rocZ',newY');
Coverages(mask_idx,run)=coverage(rocZ',newY');
[tpr,fpr] = mlr_roc(rocZ, newY);
[AUC, area2] = mlr_auc(fpr,tpr);
AUCs(mask_idx,run)=AUC;
