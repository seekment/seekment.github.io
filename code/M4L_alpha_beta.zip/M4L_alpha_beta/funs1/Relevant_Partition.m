function [Y]=Relevant_Partition(Z,thresholds)
% Relevant_Partition(Z),Divide the predicted confident into relevant (psotive) and
% irrelevant(negative) parts
% Input Z: the multi-label confident matrix (NxC), C is the number of labels
%       thresholds: the adaptive_decision_boudary for each class
% Output: Y, predicted labels in 1,1,-1,-1 forms
%   written by Guoxian Yu (guoxian85@gmail.com), School of Computer Science and Engineering,
%   South China University of Technology.
%   version 1.0 date:2011-12-11
[N,C]=size(Z);
Y=zeros(N,C);
for cc=1:C
    index=find(Z(:,cc)>thresholds(cc));
    Y(index,cc)=1;
    index2=setdiff(1:N,index);
    Y(index2,cc)=-1;
end