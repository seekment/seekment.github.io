function [W]=Construct_Weight(Y,kernel)
% Construct_Weight(Y,kernel),specifying weight using label information and kernel
%   Input Y: the multi-label matrix (NxC),in 1 and 0 form, 1 means labeled and 0 unlabeled.
%          the first L instances are labeled
%   kernel: the original weight between terms
% Output: W, NxN new weight matrix
%   written by Guoxian Yu (guoxian85@gmail.com), School of Computer Science and Engineering,
%   South China University of Technology.
%   version 1.0 date:2011-12-22
[N,C]=size(Y);
temp=sum(Y,2);
index=find(temp>0.5);
L=length(index);
U=N-L;
W=zeros(N,N);
% [aa,bb]=find(kernel>0);
% nInteractions=length(aa);
% sigma=sum(sum(kernel))/nInteractions;
% % max1=max(max(kernel));
% % min1=min(min(kernel));
% % sigma=max1-min1;
% tol=0.000001;
% if abs(sigma)<tol
%    sigma=1; 
% end
% sim=exp(-(1-kernel)/sigma);
% sim=(kernel-min1)/sigma;
% surf(1:N,1:N,sim);

W=kernel;
fprintf('\n time:%s, L=%d, L=%d\n',datestr(now),L,L);

temp1=Y(1:L,:)*(Y(1:L,:)');
for ii=1:L
    for jj=ii+1:L
        diff=abs(Y(ii,:)-Y(jj,:));
        if sum(diff)==0 % Yii and Yjj have the same labelset
            W(ii,jj)=1;
        else % Yii and Yjj have different label sets, using jaccard coefficients
            temp=Y(ii,:)+Y(jj,:);
            temp(temp==2)=1;
            W(ii,jj)=temp1(ii,jj)/sum(temp);
        end
    end
    fprintf('Time %s \t {%d} \n',datestr(now),ii);
end
W(1:L,1:L)=W(1:L,1:L)'+W(1:L,1:L);

% fprintf('time:%s, L=%d, U=%d\n',datestr(now),L,U);
% temp=kernel(1:L,L+1:N);
% for ii=1:L
%     W(ii,L+1:N)=sum(Y(ii,:))\temp(ii,:);
% end
% 
% fprintf('time:%s, U=%d, L=%d\n',datestr(now),U,L);
% temp=kernel(L+1:N,1:L);
% for jj=1:L
%     W(L+1:N,jj)=sum(Y(jj,:))\temp(:,jj);
% end
% 
% fprintf('time:%s, U=%d, U=%d\n',datestr(now),U,U);
% W(L+1:N,L+1:N)=kernel(L+1:N,L+1:N)/C;
fprintf('Time :%s Finished specification of W.\n',datestr(now));
W=W-diag(diag(W));
