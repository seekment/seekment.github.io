function [ratio]=Huzefa_Accuracy(outputY,realY,maskedY)
%   written by Guoxian Yu (guoxian85@gmail.com), School of Computer Science and Engineering,
%   South China University of Technology.
%   version 1.0 date:2012-03-30
[Ndata,Nfun]=size(realY);
if(min(min(outputY))<0)
    outputY=(outputY+abs(outputY))/2;
end

if(min(min(realY))<0)
    realY=(realY+abs(realY))/2;
end

if(min(min(maskedY))<0)
    maskedY=(maskedY+abs(maskedY))/2;
end

Y=realY-maskedY;
totalMasked=sum(sum(Y));
correct=sum(sum(Y.*outputY));
if totalMasked==0
    totalMasked=1;
end
ratio=correct/totalMasked;


