function [prec]=TopKPrecision(Z,Y,topK)
% CosLCorr: calculate the Top K Precision
% Input Y: the true multi-label matrix (NxC), C is the number of labels, in 1 and -1 form
% Input Z: the predicted multi-label matrix.
% Output: prec wrt to topK
%   written by Guoxian Yu (guoxian85@gmail.com), School of Computer Science and Engineering,
%   South China University of Technology.
%   version 1.0 date:2012-02-08
tempZ=(Z+abs(Z))/2;
tempY=(Y+abs(Y))/2;
[N,C]=size(tempY);
TPk=0;
FPk=0;
for ii=1:N
    temp=sum(tempZ(ii,:).*tempY(ii,:));
    TPk=TPk+temp;
    FPk=FPk+topK-temp;
end
prec=TPk/(TPk+FPk);