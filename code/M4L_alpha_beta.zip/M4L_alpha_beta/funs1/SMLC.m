function [ W,b ] = SMLC(X,Y,C,Ln,g_I)
%Semi-supervised Linear Classifier 
%Y=W^T*X+b
tol=0.001;
[N,D]=size(X);%number of samples and dimensionality
l=N-sum(sum(Y)==0); % labeled examples
oneT=ones(N,1);
H=zeros(N,N);
[index_i]=find(sum(Y));
index=index_i;
H(index,index)=1;
H=diag(diag(H));

Lc=H-H*oneT*oneT'*H/N;
% Lc=H;
temp=X'*(Lc+g_I*Ln)*X;
temp=tol*eye(size(temp))+temp;
W=temp\(X'*Lc*Y*C);
b=((Y*C)'-W'*X')*H*oneT/N;