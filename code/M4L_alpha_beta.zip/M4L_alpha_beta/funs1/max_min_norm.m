function y=max_min_norm(max_value,min_value,x)
%this function do max min normalization on each dimension of input feature
%vector
if(max_value<=min_value)
  error('max value can"t be lower than min value');
end

size_x=size(x);
y=zeros(size_x);
for line=1:size_x(1)
   max_line=max(x(line,:));
   min_line=min(x(line,:));
   for col=1:size_x(2)
      if(max_line==min_line)
         y(line,col)=(max_value+min_value)/2;
      else
         y(line,col)=((x(line,col)-min_line)/(max_line-min_line))*(max_value-min_value)+min_value;
      end
   end
end