function [W]=PathKernel(kernel)
% PathKernel(Y,kernel),specifying weight using path based similarity
%   Input Y: the multi-label matrix (NxC),in 1 and 0 form, 1 means labeled and 0 unlabeled.
%          the first L instances are labeled
%   kernel: the original weight between terms
% Output: W, NxN new weight matrix
%   written by Guoxian Yu (guoxian85@gmail.com), School of Computer Science and Engineering,
%   South China University of Technology.
%   version 1.0 date:2011-12-25
kernel=kernel-diag(diag(kernel));
[m,n]=size(kernel);
fprintf('begin quick sort edges: %s\n',datestr(now,'yyyy-mm-dd HH:MM:SS:FFF')');
%sort matrix element in descending order
[sorted, index] = sort(kernel(:),'descend');
clear sorted;
index = flipud(index);
[index_i, index_j] = ind2sub(size(kernel), index(1:m*n));
clear index;
edgeindex=1;
edge=[];
edge.begin=0;
edge.end=0;
edge.weight=0;
edgenum=(m-1)*n/2;% the number of edges
edges=repmat(edge,edgenum,1);

for i=1:m*n
    row=index_i(i);
    col=index_j(i);
    if(row<col)
        edges(edgeindex).begin=row;
        edges(edgeindex).end=col;
        edges(edgeindex).weight=kernel(row,col);
        edgeindex=edgeindex+1;
    end
end
clear kernel index_i index_j index;
fprintf('end sort edges: %s\n',datestr(now,'yyyy-mm-dd HH:MM:SS:FFF')');

rbsim=zeros(m,n);
parent=1:edgenum;
for i=1:edgenum;
    parent(i)=0;
end
fprintf('construct maximum spanning tree! %s\n',datestr(now,'yyyy-mm-dd HH:MM:SS:FFF')');
first=0;
second=0;
temp=0;
edgecount=0;
for i=1:edgenum
    temp=edges(i).begin;
    while (parent(temp)>0)
        temp=parent(temp);
    end
    first=temp;
    
    temp=edges(i).end;
    while(parent(temp)>0)
        temp=parent(temp);
    end
    second=temp;
    
    weight=edges(i).weight;
    if(weight==0)
        fprintf('====Can not construct fully connected tree====\n');
        break;
    end
    if(first~=second)% not in the same cluster
        parent(first)=second;
        edgecount=edgecount+1;
        rbsim(edges(i).begin,edges(i).end)=edges(i).weight;
        rbsim(edges(i).end,edges(i).begin)=edges(i).weight;
        rbsim=rbconstruct(rbsim,edges(i).weight);
%         disp([ ' add edge' num2str(first) '-' num2str(second)  '  edgeindex:' num2str(i)  '   ' num2str(edgecount) '/' num2str(m) ]);
    end
    if edgecount>m-2 
        fprintf('==== Constructed path kernel ====\n');
        break;
    end
    if(edgecount == m)
        fprintf(' ==== Still can not construct a fully connected graph! ');
    end
end

fprintf('Time :%s Finished specification of W.\n\n',datestr(now));
W=rb_sim-diag(diag(rbsim));
