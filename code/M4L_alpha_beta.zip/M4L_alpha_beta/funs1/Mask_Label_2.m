function [masked_Y]=Mask_Label_2(Y,mask_ratio)
% mask some labels of the multi-label data with mask_ratio
% Input Y: the multi-label matrix (NxC), C is the number of labels, in 1 and 0 form, 1 means labeled and 0 donates unlabeled.
%   mask_ratio: [0,1] the percentage of incomplete labels onmulti-label data
% Output: masked_Y: masked label vector with
%   written by Guoxian Yu (guoxian85@gmail.com), School of Computer Science and Engineering,
%   South China University of Technology.
%   version 1.0 date:2012-03-16
[Ndata,Nfun]=size(Y);
masked_Y=Y;
for ii=1:Ndata
    Yii=Y(ii,:);
     stat=sum(Yii);
     count=fix(stat*mask_ratio);
     if count>0
         idx=find(Yii>0);
         r_idx=randperm(length(idx));
         Yii(idx(r_idx(1:count)))=0;%masked the labels
         masked_Y(ii,:)=Yii;
     end
end