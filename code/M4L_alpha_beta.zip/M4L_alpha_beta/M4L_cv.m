function [] = M4L_cv( nTypes,instanseIdx,Gcell,Rcell,ThetaCell,alpha,beta);
LD=Rcell{4};
[NL,ND]=size(LD);
max_iter = 20;
% alpha = 10^4;     %alpha for Wr
% beta = 10^5;   %beta for Wt
% alpha = 10^7;     %alpha for Wr
% beta = 10^6;   %beta for Wt

[r_thetacell, c_thetacell] = size(ThetaCell);
theta_p = cell(r_thetacell, c_thetacell);
theta_n = cell(r_thetacell, c_thetacell);

G_enum = cell(size(Gcell));
G_denom = cell(size(Gcell));

threshold = 0.00001;
%%
round =5;
nfold = 5;

for run = 1:round
    [training, test] = Getnfold( LD,nfold );%
    for ll = 5:nfold
        t0=clock;
        testm = test(:,:,ll);
        trainingm = training(:,:,ll);
        
        Y=trainingm;
        topK=ceil(sum(sum(Y))/NL);
        Rcell{4} = Y;%��ѵ������R15
        
        for ii = 1:length(Gcell)
            G_enum{ii}=0;
            G_denom{ii} =0;
        end
        Scell = cell(size(Rcell));
        
        for ii = 1:r_thetacell
            for jj = 1:c_thetacell
                theta = ThetaCell{ii,jj};
                t = abs(theta);
                theta_p{ii,jj} = (t+theta)/2;
                theta_n{ii,jj} = (t-theta)/2;
            end
        end
        
        for iter = 1:max_iter
            %% initialize the S
            
            mus=zeros(length(Rcell),1);
            
            
            for rr = 1:length(instanseIdx)
                i = fix(instanseIdx{rr}/nTypes)+1;
                j = mod(instanseIdx{rr},nTypes);
                if j ==0
                    i = i-1;
                    j = 5;
                end
                Gmatii = Gcell{i};
                Gmatjj = Gcell{j};
                
                Rmat = Rcell{rr};
                
                %                 Smat = (Gmatii'*Gmatii)\Gmatii'*Rmat*Gmatjj/(Gmatjj'*Gmatjj);
                Smat = pinv(Gmatii'*Gmatii)*Gmatii'*Rmat*Gmatjj*pinv(Gmatjj'*Gmatjj);
                Smat(isnan(Smat))=0;
                Scell{rr}=Smat;
                
                result = Rcell{rr}-Gmatii*Scell{rr}*Gmatjj';
                R = sum(sum(result.^2));
                mus(rr)=R;
                
            end
            
           Tmus=zeros(length(Rcell),1);%6*1 �����в�
    
    
        %��2��в����
            for rr = 2:length(instanseIdx)%9
                rr=rr-1;
                if rr==1
                    result=Rcell{rr}-Rcell{rr+1}*Gcell{3}*Gcell{2}';%R12-R13*G3*G2'
                elseif rr==2
                    result=Rcell{rr}-Rcell{rr-1}*Gcell{2}*Gcell{3}';%R13-R12*G2*G3'
                elseif rr==7
                else
                     result=0;
                   
                end
            R = sum(sum(result.^2));
            Tmus(rr)=R;
            end
            
            kmus=zeros(r_thetacell, c_thetacell);
            
            for ii = 1:r_thetacell
                for jj = 1:c_thetacell
                    if ~isempty(ThetaCell{ii,jj})
                        Gmat = Gcell{ii};
                        result2= Gmat'*ThetaCell{ii,jj}*Gmat;
                        R2 = trace(result2);
                        kmus(ii,jj) = R2;
                    end
                end
            end
           mus = mus+ Tmus;
            %% get the optimal W1 weights for relation matrices according to the reconstruction loss
            [bestP1,Ws]=getOptimalW1Weights(mus,alpha);
           % fprintf('the Ws is finished!\n');
            
            %% get the optimal W2 weights for constraint matrices according to the intra-relations
            [bestP2,Wt]=getOptimalW2Weights(kmus,beta);
           %fprintf('the Wt is finished!\n');
            
            %% update G with relation matrices and constraint matrices
            for rr = 1:length(instanseIdx)
                i = fix(instanseIdx{rr}/nTypes)+1;
                j = mod(instanseIdx{rr},nTypes);
                if j ==0
                    i = i-1;
                    j = 5;
                end
                temp1 = Rcell{rr}*Gcell{j}*Scell{rr}';
                temp1(isnan(temp1))=0;
                t = abs(temp1);
                
                temp1p = (t+temp1)/2;
                temp1n = (t-temp1)/2;
                
                temp2 = Scell{rr}*Gcell{j}'*Gcell{j}*Scell{rr}';
                temp2(isnan(temp2))=0;
                t = abs(temp2);
                
                temp2p = (t+temp2)/2;
                temp2n = (t-temp2)/2;
                
                temp3 = Rcell{rr}'*Gcell{i}*Scell{rr};
                temp3(isnan(temp3))=0;
                t = abs(temp3);
                t(t<0)=0;
                temp3p = (t+temp3)/2;
                temp3n = (t-temp3)/2;
                
                temp4 = Scell{rr}'*Gcell{i}'*Gcell{i}*Scell{rr};
                temp4(isnan(temp4))=0;
                t = abs(temp4);
                t(t<0)=0;
                temp4p = (t+temp4)/2;
                temp4n = (t-temp4)/2;
                
                
                G_enum{i} = G_enum{i}+Ws(rr).* temp1p+Ws(rr).*Gcell{i}*temp2n;
                G_denom{i}= G_denom{i}+Ws(rr).*temp1n+Ws(rr).*Gcell{i}*temp2p;
                
                G_enum{j} = G_enum{j}+ Ws(rr).*temp3p+Ws(rr).*Gcell{j}*temp4n;
                G_denom{j}= G_denom{j}+Ws(rr).*temp3n+Ws(rr).*Gcell{j}*temp4p;


                
            end
            
            for ii = 1:r_thetacell
                for jj= 1:c_thetacell
                    if ~isempty(ThetaCell{ii,jj})
                        G_enum{ii} = G_enum{ii}+Wt(ii,jj).*theta_n{ii,jj}*Gcell{ii};
                        G_denom{ii} = G_denom{ii}+Wt(ii,jj).*theta_p{ii,jj}*Gcell{ii};
                    end
                end
            end
            
            for ii = 1:length(Gcell)
                G_denom{ii}=G_denom{ii}+eps;
                factor = sqrt(G_enum{ii}./G_denom{ii});
                Gcell{ii}=Gcell{ii}.*factor;
                Gcell{ii}(isnan(Gcell{ii}))=0;
                Gcell{ii}(isinf(Gcell{ii}))=0;
            end
            
            %% compare the target approximation (||R15-G1S15G5'||^2) with threshold
            
            result = Rcell{4}-Gcell{1}*Scell{4}*Gcell{5}';
            R = sum(sum(result.^2));
            if R<threshold
                break;
            end
            fprintf('the iteration is: %d RSS:%d\n',iter,R);
        end
        newF=Gcell{1}*Scell{4}*Gcell{5}';
        
        rocZ = newF;
        Ws = 0;
        wsCell1{ll} = Ws;%�����ll�۵�ws
        wtCell1{ll} = Wt;%�����ll�۵�wt
        
        Z=Top_K_Partition(rocZ',topK)';
        
        fprintf('%d round %d fold alpha:%d, \n beta: %d\n',run,ll,alpha,beta);
        microAvgF1s=Micro_Avg_F1(Z',testm');%����΢ƽ��f1
        fprintf('%d round %d fold MicroAvgF1s : %f\n',run,ll,microAvgF1s);
        
        macroAvgF1s=Macro_Avg_F1(Z',testm');%�����ƽ��f1
        fprintf('%d round %d fold MacroAvgF1s : %f\n',run,ll,macroAvgF1s);
        
%         accuracys=Accuracy(Z,testm);%����׼ȷ��
%         fprintf('%d round %d fold Accuracys : %f\n',run,ll,accuracys+0);
%         
%         hammingLosses = 1-Hamming_loss(Z',testm');%�õ�Z',testm'�Ĳ�׼ȷ��
%         fprintf('%d round %d fold HammingLosses : %f\n',run,ll,hammingLosses);
        
        
        [auc,fpr,tpr] = ROC_calculate_figure2( testm,rocZ );%��ROC����
        fprintf('The M4L %d round %d fold AUROC is %f\n',run,ll,auc);
        AUC(ll)=auc;
        TPR(:,ll)=tpr;
        FPR(:,ll)=fpr;
        
        [ results_link,test_link ] = ResultGetLinks( rocZ,testm,trainingm );
        [ aupr,prec,rec ] = PR_calculate_figure( LD,results_link,test_link);
       % aupr=0;
      %  prec = 0;
       % rec = 0;
         fprintf('The M4L %d round %d fold AUPRC is %f\n',run,ll,aupr);
        AUPR(ll) = aupr;
        Prec{ll} = prec;
        Rec{ll} = rec;

        rocZ_vec{ll} = rocZ;
        MicroAvgF1s(ll) = microAvgF1s;
        MacroAvgF1s(ll) = macroAvgF1s;
        Accuracys(ll) = accuracys;
        HammingLosses(ll) = hammingLosses;
        
        avgRecll(ll) = mean(rec);
        fprintf('The M4L %d round %d fold   \n avgRecll:%f\n',run,ll,mean(rec));
        
        avgf1_score = (2*mean(prec)*mean(rec))/(mean(prec)+mean(rec));
        avgF1_SCORE(ll) = avgf1_score;
        fprintf('The M4L %d round %d fold   \n F1_SCORE:%f\n',run,ll,avgf1_score);
        
        avgPerc = mean(prec);
        fprintf('The M4L %d round %d fold   \n avgPerc:%f\n',run,ll,avgPerc);
        
        %evalstr=['save results',filesep,'M4L',num2str(run),'_',num2str(ll),'.mat auc tpr fpr aupr prec rec  rocZ MicroAvgF1s MacroAvgF1s Accuracys HammingLosses avgRecll avgF1_SCORE avgPerc'];
       % eval(evalstr);
    end
%     wsCell{run} = wsCell1;
%     wtCell{run} = wtCell1;
%     AUC_Cell{run} = AUC;
%     TPR_Cell{run} = TPR;
%     FPR_Cell{run} = FPR;
%     rocZ_Cell{run} = rocZ_vec;
%     AUPR_Cell{run} = AUPR;
%     Prec_Cell{run} = Prec;
%     Rec_Cell{run} = Rec;
%     Accuracys_Cell{run} = Accuracys;
%     HammingLosses_Cell{run} = HammingLosses;
%     MicroAvgF1s_Cell{run} = MicroAvgF1s;
%     MacroAvgF1s_Cell{run} = MacroAvgF1s;
    
end

%evalstr=['save results',filesep,'M4L_CV.mat TPR_Cell FPR_Cell AUC_Cell Prec_Cell Rec_Cell AUPR_Cell rocZ_Cell wsCell wtCell MicroAvgF1s_Cell MacroAvgF1s_Cell Accuracys_Cell HammingLosses_Cell'];
%eval(evalstr);

end

