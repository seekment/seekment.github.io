function [maskedY] =  maskDObyNum(Y, childMap, maskCount)

t0=clock;
maskedY=Y;
[nP,nF]=size(Y);
for ii=1:nP
    Yii=Y(ii,:);
    mask_y=Yii;
    for jj=1:maskCount
        stat=sum(mask_y,2);%mask a protein if it has at least 2 annotations
        if stat>1
            mask_y=maskDOLeaf(mask_y,childMap);
        end
    end
    maskedY(ii,:)=mask_y;
%     if (mod(ii,100)==0)
%         fprintf('finished %d, now:%s\n',ii,datestr(now));
%     end
end
fprintf('Finish Mask functions, used %f seconds, %s\n', etime(clock,t0), datestr(now));