function [ B ] = GetLinks( A )
%Gets the link within the matrix and sort it in descending order
k=1;
B=[];
[m,n]=size(A);
for i=1:m
    for j=1:n
        if A(i,j)~=0
            B(k,1)=i;
            B(k,2)=j;
            B(k,3)=A(i,j);
            k=k+1;
        end
    end
end
%[m,n]=size(B)
if ~isempty(A)
    [a, ii]=sort(B(:,3),'descend');
    B = B(ii,:); 
end
end

