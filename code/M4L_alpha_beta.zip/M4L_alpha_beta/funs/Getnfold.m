function [ training, test ] = Getnfold( B,N )
%algorithm to separate data for n-fold cross validation
[m,n]=size(B);
training=zeros(m,n,N);
test=zeros(m,n,N);
for i=1:m
    for j=1:n
        if B(i,j) ~= 0;%when we reach a link
            test(i,j,ceil(N*rand))=B(i,j);
        end
    end
end
training(:,:,1)=sum(test(:,:,2:N),3);
training(:,:,N)=sum(test(:,:,1:N-1),3);
for i=2:N-1
    training(:,:,i)=sum(test(:,:,[1:i-1 i+1:N]),3);
end
end

