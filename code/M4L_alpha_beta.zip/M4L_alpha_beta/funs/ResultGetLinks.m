function [ results_link1,test_link1 ] = ResultGetLinks( results,test,training )
%UNTITLED2 �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
results_final = results;
[m,n]=size(results_final);

for j=1:m
    for k=1:n
        if results_final(j,k)~=0
            if training(j,k)~=0
                results_final(j,k)=0;%remove training set from results
            end
        end
    end
end

%%
fprintf('Getting results links from iteration 1\n');
results_link1 = GetLinks(results_final);

fprintf('Getting test links from iteration 7\n');
test_link1=GetLinks(test);

end

