function [ AUPR,prec,rec ] = PR_calculate_figure( test,results_link1,test_link1)
%%
lr=0;
pre_size = length(results_link1);
l=1:pre_size;
prec=zeros(1,length(l));
rec =zeros(1,length(l));
%aupr_vec = zeros(1,10);

for k=1:length(l)
    %The 1 fold test
    for i=1:l(k)
        if test(results_link1(i,1),results_link1(i,2))~=0%check if predicted links are in training data
            lr=lr+1;%TP
        end
    end
    prec(k)=lr/l(k);%calculate precision, l(k)(TP+FP)
    rec(k)=lr/length(test_link1);%calculate recall, length(test_link1)��TP+FN��
    lr = 0;
end


%%
ts = 0;

ta = prec;
tb = rec;
for jj=1:length(ta)-1,
    ts = ts + (ta(jj)-ta(jj+1))*(tb(jj)+tb(jj+1))/2 ;
end ;


AUPR = ts;
fprintf('AUPR: %d\n',AUPR);

plot(rec, prec);
xlabel('Recall');
ylabel('Precision');
title('Precision-Recall Curve');


end

