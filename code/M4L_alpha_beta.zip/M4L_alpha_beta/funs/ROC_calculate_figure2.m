function [ AUC,fpr,tpr ] = ROC_calculate_figure2( test,result )
%UNTITLED �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
fprintf('ROC_calculate_figure2 is starting\n');
ground_truth = test;
ground_truth = ground_truth(:);
predict = result;
predict = predict(:);
[x,y] = plot_roc(predict,ground_truth);
fpr(1,:) = x;
tpr(1,:) = y;
fprintf('roc calculate time is %s\n',datestr(now));

%%
m = size(ground_truth,1);

a = zeros(m+1,1);
b =zeros(m+1,1);
a(1)=1;
b(1)=1;
a = tpr;
b = fpr;
a(m+1)=0;
b(m+1)=0;
s=0 ;
for i=1:length(a)-1,
    s = s + (a(i)-a(i+1))*(b(i)+b(i+1))/2 ;
end ;
AUC = 1-s;
fprintf('AUC: %d\n',AUC);
save(['results\','auc'],'AUC');%

 plot(fpr, tpr);
 xlabel('FPR');
 ylabel('TPR');
 title('AUC Curve');

end

