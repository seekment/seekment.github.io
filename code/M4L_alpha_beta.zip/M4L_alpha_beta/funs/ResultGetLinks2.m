function [ results_link1,test_link1 ] = ResultGetLinks2( results,test )
%UNTITLED2 �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
results_final = results;
[m,n]=size(results_final);

%%
fprintf('Getting results links from iteration 1\n');
results_link1 = GetLinks(results_final);

fprintf('Getting test links from iteration 7\n');
test_link1=GetLinks(test);

end

