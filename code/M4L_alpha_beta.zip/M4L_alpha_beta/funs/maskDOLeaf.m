function [masked_y] = maskDOLeaf(y, childMap)

masked_y=y;
idxs=find(y>0);%find the go index
childs = childMap(idxs,:);

bLeafs=zeros(length(idxs),1);

for ii=1:length(idxs)%find all the `leaf' node of this protein
    childDO =find(childs(ii,:));
    commonDOs=intersect(childDO,idxs);
    if isempty(commonDOs)
        bLeafs(ii)=1;
    end
end

num_leaf=sum(bLeafs);
leafIdx=find(bLeafs);
if(num_leaf>=1)
    randIdx=randperm(num_leaf);
    maskIdx=randIdx(1);
    maskIdx1=leafIdx(maskIdx);
    maskIdx2=idxs(maskIdx1);
    masked_y(maskIdx2)=0;
end