clear all;
clc;
funspath=[pwd,filesep,'data',filesep];
addpath(funspath);
funspath=[pwd,filesep,'funs',filesep];
addpath(funspath);
funspath=[pwd,filesep,'funs1',filesep];
addpath(funspath);

%% load data to construct the relation matrix R
load('lncRNAMiA')
R12 = lncMI;
[nlnc,nmi] = size(lncMI);
load('lncRNAGene')
R13 = LGasso;
load('lncRNAGOs');
R14 = [lncBPs lncCCs lncMFs];
load('LncDOs')
load('lncDisease2')
LncDO = lncDisease + LncCancer;
LncDO(LncDO>1)=1;
R15 = LncDO;
load('MiDOs')
R25 = miDOs;
load('miRNAGene')
R23 = MGasso;
load('GeneDisease')
R35 = GDasso;
[npro,ndi] = size(GDasso);
load('HumanGOAs')
R34 = [bpLabels ccLabels mfLabels];
nGO = size(R34,2);

%% filter the no instanse disease.
fun_stat = sum(R15,1);
sel_do_idx = find(fun_stat>0);
R15 = R15(:,sel_do_idx);
R25 = R25(:,sel_do_idx);
R35 = R35(:,sel_do_idx);
ndi = length(sel_do_idx);

Rcell={R12,R13,R14,R15,R23,R25,R34,R35};

load('ThetaCell');

R1 = [R12 R13 R14];
R2 = [R23 R25];
R3 = [R23' R35];
R4 = R14';
R5 = [R25' R35'];


KValue=150;
% %k1=220;
 k1=KValue;
 %k2=220;
k2=KValue;
k3=KValue;
% k4=20;
 k4=KValue;
% k5=50;
k5=KValue;
 [G1,z1]=learnVector2(R1,k1);
 [G2,z2]=learnVector2(R2,k2);
[G3,z3]=learnVector2(R3,k3);
 [G4,z4]=learnVector2(R4,k4);
[G5,z5]=learnVector2(R5,k5);
% 
 Gcell = {G1,G2,G3,G4,G5};
% save('Gcell_M4L_0122.mat','Gcell');
% Gcell = importdata('Gcell_M4L_0122.mat');

%%
%�����ض����ļ�������Ū4���ط���1�������½ڴ��롣2�����ֻʹ��fprintf���������ض���fid.3)����fid/4���ر��ļ�

%%



fprintf('Gcell is load complecated\n');
%%
instanseIdx = {2,3,4,5,8,10,14,15};      % instanse index for the corresponding position in the whole relation matrix R
fprintf('begin,time:%s\n',datestr(now));
t0=clock;
nTypes=5;
%M4L_cv( nTypes,instanseIdx,Gcell,Rcell,ThetaCell);
for i=-2:10
    alpha = 10^i;
    for j=-2:10
        beta = 10^j;
        M4L_cv( nTypes,instanseIdx,Gcell,Rcell,ThetaCell,alpha,beta);
    end
end

